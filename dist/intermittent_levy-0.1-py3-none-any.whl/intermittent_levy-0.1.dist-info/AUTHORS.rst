Authors
=======

This package, **IntLevy-Processes**, is being developed and maintained by `Shailendra Bhandari <https://github.com/shailendrabhandari/>`_.

Lead Development Team
---------------------

The following individuals form the core development team:

- **Shailendra Bhandari** (`shailendra.bhandari@oslomet.no <mailto:shailendra.bhandari@oslomet.no>`_)
- **Pedro Lencastre** (`pedroreg@oslomet.no <mailto:pedroreg@oslomet.no>`_)
- **Sergiy Denysov** (`sergiyde@oslomet.no <mailto:sergiyde@oslomet.no>`_)
- **Anis Yazidi** (`anisy@oslomet.no <mailto:anisy@oslomet.no>`_)
- **Yuri Bystrik**
- **Pedro G. Lind** (`pedrolin@oslomet.no <mailto:pedrolin@oslomet.no>`_)

Contributors
------------

- **Pedro Lencastre** (`pedroreg@oslomet.no <mailto:pedroreg@oslomet.no>`_)

Citing IntLevy-Processes
------------------------

If you would like to cite **IntLevy-Processes** in your work, please refer to the citation guidelines, which will be announced soon.

